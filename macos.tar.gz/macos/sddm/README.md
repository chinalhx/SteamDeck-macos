
MacSequoia sddm theme for KDE Plasma desktop.

## Installation

./install.sh

## Donate

If you like my project, you can donate at:

<span class="paypal"><a href="https://www.paypal.me/vinceliuice" title="Donate to this project using Paypal"><img src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-100px.png" alt="PayPal donate button" /></a></span>

## License

GNU GPL v3

## preview

![light](images/Preview-Light.jpg)
![dark](images/Preview-Dark.jpg)
